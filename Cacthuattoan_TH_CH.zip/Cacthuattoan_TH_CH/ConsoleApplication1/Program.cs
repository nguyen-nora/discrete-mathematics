﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.ComponentModel;
using System.IO;
namespace ConsoleApplication1
{
    class Program
    {
        static int n, k, dem, final;
        static string FileName = "E:\\test.txt"; 
        static int [] a = new int[ToanCuc.nrobjs];
        static set A, B, U;
        static int[] C, T;
        static void Main(string[] args)
        {
            /* Lab 01
            Console.WriteLine("Nhap vào gia tri cho n < 13.");
            n = int.Parse(Console.ReadLine());
            final = 1;
            khoitao();
            //XuatTatcaTapCon();
            XuatTatcaTapConChar();
            Console.ReadLine();
            */
            /* Lab 2
            Console.Clear();
            Menu();
            while (true)
            {
                int t = XuLyMenu();
                if (t == 0) break;
            }    
            */
            /* CHINH HOP
            do{
                    Console.WriteLine("Nhap vào gia tri cho n.");
                    n = int.Parse(Console.ReadLine());
                    Console.WriteLine("Nhap vào gia tri cho k.");
                    k = int.Parse(Console.ReadLine());
            }while(n < k);
            C = new int[n+1];
            T = new int[n+1];
            for (int i = 1; i <= n; i++)
                C[i] = 0;
            dem = 0;
            ChinhHop(1);
            Console.WriteLine("dem:"+ dem.ToString());
            */ 
            // TO HOP CHẬP K CỦA TẬP N PHẦN TỬ
            do
            {
                Console.WriteLine("Nhap vào gia tri cho n.");
                n = int.Parse(Console.ReadLine());
                Console.WriteLine("Nhap vào gia tri cho k.");
                k = int.Parse(Console.ReadLine());
            } while (n < k);
            T = new int[n + 1];
            dem = 0;
            ToHopKN();
            Console.WriteLine("dem:" + dem.ToString());
            //Console.ReadLine();
            Console.ReadKey();
        }
        static void XuatMang(int[] A, int n)
        {
            for (int i = 1; i <= n; i++)
                Console.Write(A[i].ToString() + " ");
            Console.WriteLine();
        }
        static void ToHopKN()
        {
            int i, p;
            for (i = 1; i <= k; i++) T[i] = i;
            p = k;
            while(p >= 1)
            {
                dem++;
                Console.Write("\n Tap con thu " + dem.ToString() + " : ");
                XuatMang(T, k);
                // 2 IF SAU DE TANG DAN THEO Y TUONG CUA THUAT TOAN
                if (T[k] == n) p--; else p = k;
                if (p >= 1) for (i = k; i >= p; i--) T[i] = T[p] + i - p + 1; // 
            }               
        }
        static void ChinhHop(int i)
        {
            for (int j = 1; j <= n; j++)
                if (C[j] == 0)
                {
                    T[i] = j;
                    if (i == k)
                    {
                        XuatMang(T, k); 
                        dem++;
                    }
                    else
                    {
                        C[j] = 1;
                        ChinhHop(i + 1);
                        C[j] = 0;
                    }
                }
        }     
        static int ChonMenu()
        {
            int n = 0;
            try
            {
                Console.Write("\n\n Chon tren menu thuc hien cac thuat toan khac : ");
                n = int.Parse(Console.ReadLine());
                
            }
            catch (Exception loi)
            {
                Console.Write("\n Nhap sai !!!");
                Console.WriteLine(loi.Message);
            }
            if ((n > 0 || n < 9)|| n != 99)
                return n;
            else return ChonMenu();

            
        }
        static void Menu()
        {
            Console.Write("=============================MENU===========================\n");
            Console.Write("1. Nhap Tap vu tru U, Tap hop A và Tap hop B \n");
            Console.Write("2. Kiem tra phan tu co thuoc Tap hop A hay khong? \n");
            Console.Write("3. Kiem tra Tap hop A la con tap hợp Tap hop B? \n");
            Console.Write("4. Giao cua Tap hop A va Tap hop B \n");
            Console.Write("5. Hop cua Tap hop A và Tap hop B \n");
            Console.Write("6. Hieu cua Tap hop A và Tap hop B \n");
            Console.Write("7. Bu cua Tap hop A trong U\n");
            Console.Write("8. Hieu doi xung cua Tap hop A và Tap hop B \n");
            Console.Write("99. Thoat!!!\n");
            Console.Write("============================================================\n");
        }
        static int XuLyMenu()
        {
            int chon = ChonMenu();
            //int n;// a = 5; int b = 6;
            
            switch (chon)
            {
                case 1:
                    Console.Clear();
                    Menu();
                    Console.Write("1. Nhap Tap vu tru U, Tap hop A và Tap hop B \n ");
                    NhapTapU();
                    NhapTapA();
                    NhapTapB();                                 
                    break;
                case 2:
                    Console.Clear();
                    Menu();
                    Console.Write("2. Kiem tra phan tu co thuoc Tap hop A? \n");
                    Console.Write("A : "); A.display();
                    int pt = 0;
                    try
                    {
                        Console.Write("\n Nhap ky tu can kiem tra co thuoc A: ");
                        pt = int.Parse(Console.ReadLine());
                    }
                    catch (Exception loi)
                    {
                        Console.Write("\n Nhap sai !!!");
                        Console.WriteLine(loi.Message);
                    }
                    if (A.PtInSet(pt, A)) Console.WriteLine("\n Phan tu " + pt + " thuoc Tap hop A.");
                    else {  
                            Console.WriteLine("\n Phan tu " + pt + " khong thuoc Tap hop A"); 
                            A.display(); 
                    }

                    break;
                case 3:
                    Console.Clear();
                    Menu();
                    Console.Write("A : "); A.display(); Console.WriteLine();
                    Console.Write("B : "); B.display(); Console.WriteLine();
                    Console.Write("\n 3. Kiem tra Tap hop A là con Tap hop B \n");
                    if (A.setAInB(A,B)) Console.WriteLine("\n Tap hop A thuoc Tap hop B.");
                    else Console.WriteLine("\n Tap hop A KHONG thuoc Tap hop B..");
                    break;
                case 4:
                    Console.Clear();
                    Menu();
                    Console.Write("A : "); A.display(); Console.WriteLine();
                    Console.Write("B : "); B.display(); Console.WriteLine();
                    Console.Write("4. Giao cua Tap hop A và Tap hop B \n");
                    A.Intersect(A, B).display();
                    break;
                case 5:
                    Console.Clear();
                    Menu();
                    Console.Write("A : "); A.display(); Console.WriteLine();
                    Console.Write("B : "); B.display(); Console.WriteLine();
                    Console.Write("5. Hop cua Tap hop A và Tap hop B \n");
                    A.Union(A, B).display();
                    break;
                case 6:
                    Console.Clear();
                    Menu();
                    Console.Write("A : "); A.display(); Console.WriteLine();
                    Console.Write("B : "); B.display(); Console.WriteLine();
                    Console.Write("6. Hieu cua Tap hop A và Tap hop B \n");
                    A.Subtraction(A, B).display();
                    break;
                case 7:
                    Console.Clear();
                    Menu();
                    Console.Write("U : "); U.display(); Console.WriteLine();
                    Console.Write("A : "); A.display(); Console.WriteLine();
                    Console.Write("7. Bu cua Tap hop A trong U (U - A): \n");
                    A.NotsetA(U, A).display();
                    break;
                case 8:
                    Console.Clear();
                    Menu();
                    Console.Write("A : "); A.display(); Console.WriteLine();
                    Console.Write("A : "); B.display(); Console.WriteLine();
                    Console.Write("8. Hieu doi xung cua Tap hop A va Tap hop B \n");
                    A.SubtractionAB_BA(A, B).display();
                    break;
                case 99:
                    Console.Clear();
                    Menu();
                    Console.Write("Thoat!!!\n");
                    return 0;
                    //break;
            }
            return 1;
          
        }
        static void NhapTapU()
        {
            int kt;
            Console.Write("\n 1. Nhap Tap Vu tru U \n");
            int ktU = 0;
            try
            {
                Console.Write("\n Nhap kich thuoc U la mot so nguyen co kich thuoc nho hơn " + ToanCuc.nrobjs.ToString() + ": ");
                ktU = int.Parse(Console.ReadLine());
            }
            catch (Exception loi)
            {
                Console.Write("\n Nhap sai !!!");
                Console.WriteLine(loi.Message);
            }
            List<int> no = new List<int>();
            for (int i = 0; i < ktU; i++)
            {
                kt = 0;
                try
                {
                    Console.Write("\n Nhap tung phan tu cua U la cac so nguyen duong tu 1 đến " + ToanCuc.nrobjs.ToString()+ ": ");
                    kt = int.Parse(Console.ReadLine());
                }
                catch (Exception loi)
                {
                    Console.Write("\n Nhap sai !!!");
                    Console.WriteLine(loi.Message);
                }
                no.Add(kt);
            }
            U = new set(ktU, no);
            U.display();
        }
        static void NhapTapA()
        {
            int kt;
            Console.Write("\n 1. Nhap Tap hop A \n");
            int ktA = 0;
            try
            {
                Console.Write("\n Nhap kich thuoc A la mot so nguyen co kich thuoc nho hơn " + ToanCuc.nrobjs.ToString() + " : ");
                ktA = int.Parse(Console.ReadLine());
            }
            catch (Exception loi)
            {
                Console.Write("\n Nhap sai !!!");
                Console.WriteLine(loi.Message);
            }
            List<int> na = new List<int>();
            for (int i = 0; i < ktA; i++)
            {
                kt = 0;
                try
                {
                    Console.Write("\n Nhap tung phan tu cua A la cac so nguyen duong tu 1 đến " + ToanCuc.nrobjs.ToString()+ " : ");
                    kt = int.Parse(Console.ReadLine());
                }
                catch (Exception loi)
                {
                    Console.Write("\n Nhap sai !!!");
                    Console.WriteLine(loi.Message);
                }
                na.Add(kt);
            }
            A = new set(ktA, na);
            A.display();
        }
        static void NhapTapB()
        {
            int kt;
            Console.Write("\n 1. Nhap Tap hop B \n");
            int ktB = 0;
            try
            {
                Console.Write("\n Nhap kich thuoc B la mot so nguyen co kich thuoc nho hơn " + ToanCuc.nrobjs.ToString()+ " : ");
                ktB = int.Parse(Console.ReadLine());
            }
            catch (Exception loi)
            {
                Console.Write("\n Nhap sai !!!");
                Console.WriteLine(loi.Message);
            }
            List<int> nb = new List<int>();
            for (int i = 0; i < ktB; i++)
            {
                kt = 0;
                try
                {
                    Console.Write("\n Nhap tung phan tu cua B la cac so nguyen duong tu 1 đến " + ToanCuc.nrobjs.ToString()+ " : ");
                    kt = int.Parse(Console.ReadLine());
                }
                catch (Exception loi)
                {
                    Console.Write("\n Nhap sai !!!");
                    Console.WriteLine(loi.Message);
                }
                nb.Add(kt);
            }
            B = new set(ktB, nb);
            B.display();
        }
        static void XuatTatcaTapConChar()
        {
            File.Delete(FileName);// Xoa nội dung trên file cũ
            while (final == 1)
            {
                // Khởi tạo một tập hợp
                set C = new set(ToanCuc.nrobjs);
                // Khởi tạo chuỗi kết quả k
                int k = 0;
                for (int i = 1; i < n; i++)
                {
                    if (a[i] != 0)
                    {
                        C.o.Insert(k, ToanCuc.Kytu[i]);
                        k++;
                    }
                }
                if (a[n] != 0)
                {
                    C.o.Insert(k, ToanCuc.Kytu[n]);
                    k++;
                }
                C.nmember = k;
                C.display();
                // Chèn tập hợp vào File thông qua hàm Ctostring()
                File.AppendAllText(FileName, C.Ctostring() + "\r\n");
                Console.WriteLine();
                // Sinh mảng nhị phân tiếp theo
                Sinh();
            }
        }
        static void khoitao()
        {
            for (int i = 1; i <= n; i++)
                a[i] = 0;
             
        }

        static void Sinh()
        {
            int i = n;
            
            while (i >= 1 && a[i] == 1) // Duyệt các phần tử từ n tới 1. Neu gap bit 1 chuyên thanh 0 va dich sach trai. Neu gap bit 0 chuyen thanh 1 và copy phan con lai
            {
                a[i] = 0;
                --i;
                
            }
            if (i == 0) final = 0; // Cau hinh cuoi cung --> Xuất 111
            else
            {
                a[i] = 1;
              
            }
        }
    }
}
