﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication1
{
    public class ToanCuc
    {
     
        public static int nrobjs = 100;
        public static string[] animals = new string[10] { "Chim", "Ca", "Ngong", "Heo", "Mo vit", "Nhim", "Te giac", "Bach tuoc", "Ga", "Muc"};
        //public static char[] Kytu = new char[13] {'o', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'k', 'l', 'm', 'n'};
        public static char[] Kytu = new char[27] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '\0' };
       
        
       
   }
}
